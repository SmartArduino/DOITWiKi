



#ifndef DOIT_SERVO_H
#define DOIT_SERVO_H

#include "Adafruit_PWMServoDriver.h"
#if ARDUINO > 22
  #include "Arduino.h"
#else
  #include "WProgram.h"
#endif


#ifdef __AVR__
  // AVR
  #include <avr/io.h>
  #define CTRL_CLK        4
  #define CTRL_BYTE_DELAY 3
#else
  // Pic32...
  #include <pins_arduino.h>
  #define CTRL_CLK        5
  #define CTRL_CLK_HIGH   5
  #define CTRL_BYTE_DELAY 4
#endif 






class SERVO  : public Adafruit_PWMServoDriver{
  public:
  void init();
  void setdegree(int pins, int degree, int kinds);
  int SERVOMIN=125;
  int SERVOMAX=600;
  int SERVOMID=375;
};







#endif