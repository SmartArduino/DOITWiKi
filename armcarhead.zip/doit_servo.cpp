


#include "doit_servo.h"
#include <math.h>
#include <stdio.h>
#include <stdint.h>
#include <avr/io.h>
#if ARDUINO > 22
  #include "Arduino.h"
#else
  #include "WProgram.h"
  #include "pins_arduino.h"
#endif


void SERVO::init( )
{   
        
    Adafruit_PWMServoDriver();
    begin();
    setPWMFreq(60);

}


void   SERVO::setdegree(int pins, int degree, int kinds)
{
    int pulselen=0;                                                                                                                                                                                                                                                                                                                                                                                                             
    if(degree<0)
    {
        degree=0;
    }
     if(degree>180)
    {
        degree=180;
    }
    pulselen=(degree*((SERVOMAX-SERVOMIN)/180.0))+SERVOMIN;
    setPWM(pins, 0, pulselen);
}