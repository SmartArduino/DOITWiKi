
#ifndef DOIT_MOTER_H
#define DOIT_MOTER_H

#if ARDUINO > 22
  #include "Arduino.h"
#else
  #include "WProgram.h"
#endif


#ifdef __AVR__
  // AVR
  #include <avr/io.h>
  #define CTRL_CLK        4
  #define CTRL_BYTE_DELAY 3
#else
  // Pic32...
  #include <pins_arduino.h>
  #define CTRL_CLK        5
  #define CTRL_CLK_HIGH   5
  #define CTRL_BYTE_DELAY 4
#endif 



class MOTER{
  public:
  void init(int PWMA,int DIRA,int PWMB,int DIRB,int PWMC,int DIRC,int PWMD,int DIRD);
  void setspeed(int motorId, int motorDir, int speed);
  void move(int dir, int speed);
  private:
  int MOTER_PWMA = 9;
  int MOTER_DIRA = 8;
  int MOTER_PWMB = 6;
  int MOTER_DIRB = 7;
  int MOTER_PWMC = 5;
  int MOTER_DIRC = 4;
  int MOTER_PWMD = 2;
  int MOTER_DIRD = 3;
  
};









#endif