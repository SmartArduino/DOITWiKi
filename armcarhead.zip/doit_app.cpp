

#include "doit_app.h"
#include <math.h>
#include <stdio.h>
#include <stdint.h>
#include <avr/io.h>
#if ARDUINO > 22
  #include "Arduino.h"
#else
  #include "WProgram.h"
  #include "pins_arduino.h"
#endif



void APP::serial_process(){
if(Serial.available()){ 
  char temp = Serial.read();
    Serial.println(temp);
    command =-1;
    switch(temp)
    {
        case servo_0_left_recive_char:command = servo_0_left;break;
        case servo_0_right_recive_char:command = servo_0_right;break;
        case servo_1_left_recive_char:command = servo_1_left;break;
        case servo_1_right_recive_char:command = servo_1_right;break;
        case servo_2_left_recive_char:command = servo_2_left;break;
        case servo_2_right_recive_char:command = servo_2_right;break;
        case servo_3_left_recive_char:command = servo_3_left;break;
        case servo_3_right_recive_char:command = servo_3_right;break;
        case servo_4_left_recive_char:command = servo_4_left;break;
        case servo_4_right_recive_char:command = servo_4_right;break;
        case servo_5_left_recive_char:command = servo_5_left;break;
        case servo_5_right_recive_char:command = servo_5_right;break;
        case servo_6_left_recive_char:command = servo_6_left;break;
        case servo_6_right_recive_char:command = servo_6_right;break;
        case servo_7_left_recive_char:command = servo_7_left;break;
        case servo_7_right_recive_char:command = servo_7_right;break;
        case servo_8_left_recive_char:command = servo_8_left;break;
        case servo_8_right_recive_char:command = servo_8_right;break;
        case servo_9_left_recive_char:command = servo_9_left;break;
        case servo_9_right_recive_char:command = servo_9_right;break;
        case servo_10_left_recive_char:command = servo_10_left;break;
        case servo_10_right_recive_char:command = servo_10_right;break; 
        case servo_11_left_recive_char:command = servo_11_left;break;
        case servo_11_right_recive_char:command = servo_11_right;break;        
        case servo_12_left_recive_char:command = servo_12_left;break;
        case servo_12_right_recive_char:command = servo_12_right;break;        
        case servo_13_left_recive_char:command = servo_13_left;break;
        case servo_13_right_recive_char:command = servo_13_right;break;        
        case servo_14_left_recive_char:command = servo_14_left;break;
        case servo_14_right_recive_char:command = servo_14_right;break;           
        case servo_15_left_recive_char:command = servo_15_left;break;
        case servo_15_right_recive_char:command = servo_15_right;break; 
        case car_move_up_recive_char:command = car_move_up;break; 
        case car_move_right_recive_char:command = car_move_right;break; 
        case car_move_left_recive_char:command = car_move_left;break; 
        case car_move_down_recive_char:command = car_move_down;break; 
        case car_move_stop_recive_char:car_move_stop;break;
        case car_obstacle_recive_char:command =car_obstacle;break;
        case car_tracking_recive_char:command =car_tracking;break;
        case car_speed_left_recive_char:command =car_speed_left;break;
        case car_speed_right_recive_char:command =car_speed_right;break;
        default:break;
    }
    
    }
}    

    

  bool APP::button_pressed(int btn){
      if(command==btn){
        command=-1;
        return true;}
      else return false;
    }
