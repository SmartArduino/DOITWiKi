



#ifndef DOIT_APP_H
#define DOIT_APP_H

#if ARDUINO > 22
  #include "Arduino.h"
#else
  #include "WProgram.h"
#endif


#ifdef __AVR__
  // AVR
  #include <avr/io.h>
  #define CTRL_CLK        4
  #define CTRL_BYTE_DELAY 3
#else
  // Pic32...
  #include <pins_arduino.h>
  #define CTRL_CLK        5
  #define CTRL_CLK_HIGH   5
  #define CTRL_BYTE_DELAY 4
#endif 

//define servo command
#define servo_0_left  0
#define servo_0_right 1
#define servo_1_left  2
#define servo_1_right 3
#define servo_2_left  4
#define servo_2_right 5
#define servo_3_left  6
#define servo_3_right 7
#define servo_4_left  8
#define servo_4_right 9
#define servo_5_left  10
#define servo_5_right 11
#define servo_6_left  12
#define servo_6_right 13
#define servo_7_left  14
#define servo_7_right 15
#define servo_8_left  16
#define servo_8_right 17
#define servo_9_left  18
#define servo_9_right 19
#define servo_10_left  20
#define servo_10_right 21
#define servo_11_left  22
#define servo_11_right 23
#define servo_12_left  24
#define servo_12_right 25
#define servo_13_left  26
#define servo_13_right 27
#define servo_14_left  28
#define servo_14_right 29
#define servo_15_left  30
#define servo_15_right  31

//define car command
#define car_move_up 32
#define car_move_left 33
#define car_move_down 34
#define car_move_right 35
#define car_move_stop {digitalWrite(9,0);digitalWrite(6,0);digitalWrite(5,0);digitalWrite(3,0);}  
#define car_obstacle 36
#define car_tracking 37
#define car_speed_left 38
#define car_speed_right 39


//define servo serial recive char
#define servo_0_left_recive_char    'A'
#define servo_0_right_recive_char   'a'
#define servo_1_left_recive_char    'B'
#define servo_1_right_recive_char   'b'
#define servo_2_left_recive_char    'C'
#define servo_2_right_recive_char   'c'
#define servo_3_left_recive_char    'D'
#define servo_3_right_recive_char   'd'
#define servo_4_left_recive_char    'E'
#define servo_4_right_recive_char   'e'
#define servo_5_left_recive_char    'F'
#define servo_5_right_recive_char   'f'
#define servo_6_left_recive_char    'G'
#define servo_6_right_recive_char   'g'
#define servo_7_left_recive_char    'H'
#define servo_7_right_recive_char   'h'
#define servo_8_left_recive_char    'I'
#define servo_8_right_recive_char   'i'
#define servo_9_left_recive_char    'J'
#define servo_9_right_recive_char   'j'
#define servo_10_left_recive_char    'K'
#define servo_10_right_recive_char   'k'
#define servo_11_left_recive_char    'L'
#define servo_11_right_recive_char   'l'
#define servo_12_left_recive_char    'N'
#define servo_12_right_recive_char   'n'
#define servo_13_left_recive_char    'M'
#define servo_13_right_recive_char   'm'
#define servo_14_left_recive_char    'O'
#define servo_14_right_recive_char   'o'
#define servo_15_left_recive_char    'P'
#define servo_15_right_recive_char   'p'

//define car serial recive char
#define car_move_up_recive_char   '2'
#define car_move_left_recive_char   '4'
#define car_move_right_recive_char   '6'
#define car_move_down_recive_char   '8'
#define car_move_stop_recive_char   '5'
#define car_obstacle_recive_char '3'
#define car_tracking_recive_char '1'
#define car_speed_left_recive_char 'Y'
#define car_speed_right_recive_char 'y'



class APP{
  public:
  void serial_process();
  bool button_pressed(int btn);
  
  
  int command =-1;
};


#endif