#include "doit_moter.h"


void MOTER::init(int PWMA,int DIRA,int PWMB,int DIRB,int PWMC,int DIRC,int PWMD,int DIRD){
   MOTER_PWMA = PWMA;
   MOTER_DIRA = DIRA;
   
   MOTER_PWMB = PWMB;
   MOTER_DIRB = DIRB;
   
   MOTER_PWMC = PWMC;
   MOTER_DIRC = DIRC;
   
   MOTER_PWMD = PWMD;
   MOTER_DIRD = DIRD;
   
  pinMode(MOTER_PWMA, OUTPUT);
  pinMode(MOTER_PWMB, OUTPUT);
  pinMode(MOTER_PWMC, OUTPUT);
  pinMode(MOTER_PWMD, OUTPUT);
  
  pinMode(MOTER_DIRA, OUTPUT);
  pinMode(MOTER_DIRB, OUTPUT);
  pinMode(MOTER_DIRC, OUTPUT);
  pinMode(MOTER_DIRD, OUTPUT);
  
  digitalWrite(MOTER_PWMA, LOW);
  digitalWrite(MOTER_PWMB, LOW);
  digitalWrite(MOTER_PWMC, LOW);
  digitalWrite(MOTER_PWMD, LOW);
  
  digitalWrite(MOTER_DIRA, LOW);
  digitalWrite(MOTER_DIRB, LOW);
  digitalWrite(MOTER_DIRC, LOW);
  digitalWrite(MOTER_DIRD, LOW);
}

void MOTER::setspeed(int motorId, int motorDir, int speed) {
  int speedPin, directionPin;
  if (motorId == 1) {         // motor 1
    speedPin = MOTER_PWMA;
    directionPin = MOTER_DIRA;
  } else if (motorId == 2) {  // motor 2
    speedPin = MOTER_PWMB;
    directionPin = MOTER_DIRB;
  } else if (motorId == 3) {  // motor 3
    speedPin = MOTER_PWMC;
    directionPin = MOTER_DIRC;
  } else if (motorId == 4) {  // motor 4
    speedPin = MOTER_PWMD;
    directionPin = MOTER_DIRD;
  } else {
    return;
  }
  if(speed>255){
   speed=255;
  }
  if(speed<0){
   speed=0;
  }
  if (speed == 0) {
    digitalWrite(speedPin, 0);
  } else {
    if(motorDir == 0) {
      digitalWrite(directionPin, LOW);
      analogWrite(speedPin, speed);
    } else if(motorDir == 1) {
      digitalWrite(directionPin, HIGH);
      analogWrite(speedPin, speed);
    }
  }
}

void MOTER::move(int dir, int speed){
  if(dir==1) //forward
  {
      setspeed(1,1,speed);
      setspeed(2,1,speed);
      setspeed(3,1,speed);
      setspeed(4,1,speed);
  }
    if(dir==2) //backward
  {
      setspeed(1,0,speed);
      setspeed(2,0,speed);
      setspeed(3,0,speed);
      setspeed(4,0,speed);
  }
    if(dir==3) //left
  {
      setspeed(1,0,speed);
      setspeed(2,1,speed);
      setspeed(3,0,speed);
      setspeed(4,1,speed);
  }
    if(dir==4) //right
  {
      setspeed(1,1,speed);
      setspeed(2,0,speed);
      setspeed(3,1,speed);
      setspeed(4,0,speed);
  }
    if(dir==5) //stop
  {
      setspeed(1,1,0);
      setspeed(2,1,0);
      setspeed(3,1,0);
      setspeed(4,1,0);
  }  
}